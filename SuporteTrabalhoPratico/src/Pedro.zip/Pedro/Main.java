package Pedro;

public class Main {
    public static void main(String[] args) {

        Jogador quim = new Jogador();


        System.out.println("_______________________________");
        quim.exibirDetalhes();
    }
}
