package Pedro;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Questionario {

    private String nomeQuestionario;
    private ArrayList<Pergunta> listaPerguntas;

    public Questionario(String nomeQuestionario) {
        this.nomeQuestionario = nomeQuestionario;
        this.listaPerguntas= new ArrayList<>();
    }

    public String getNomeQuestionario() {
        return nomeQuestionario;
    }

    public ArrayList<Pergunta> getListaPerguntas() {
        return listaPerguntas;
    }

    public void adicionarPergunta(Pergunta perguntaNova) {
        this.listaPerguntas.add(perguntaNova);
        Collections.shuffle(this.listaPerguntas);
    }


}
