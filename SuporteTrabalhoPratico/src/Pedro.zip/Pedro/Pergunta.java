package Pedro;

import java.util.ArrayList;
import java.util.Collections;

public class Pergunta {

    private String textoPergunta;
    private ArrayList<Resposta> respostasPossiveis;

    public Pergunta(String textoPergunta) {
        this.textoPergunta = textoPergunta;
        this.respostasPossiveis = new ArrayList<>();
    }

    public ArrayList<Resposta> getRespostasPossiveis() {
        return respostasPossiveis;
    }

    public void adicionarRespostaPossivel(Resposta novaRespostaPossivel) {
        this.respostasPossiveis.add(novaRespostaPossivel);
        Collections.shuffle(this.respostasPossiveis);
    }

    public String getTextoPergunta() {
        return textoPergunta;
    }

    public void apresentarRespostas() {
        int contador = 1;
        for (Resposta respostaAtual : this.respostasPossiveis) {
            System.out.println("[" + contador++ + "] " + respostaAtual.getTextoResposta());
        }
    }


}
