package Pedro;

public enum ObjetivoVida {
    MILIONARIO,FAMILIA,CELEBRIDADE,ARTISTA
}
