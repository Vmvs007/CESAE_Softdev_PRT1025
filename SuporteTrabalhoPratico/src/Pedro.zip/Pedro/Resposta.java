package Pedro;

public class Resposta {

    private String textoResposta;
    private int sono;
    private int comida;
    private int social;
    private int tendenciaMilionaria;
    private int tendenciaFamiliar;
    private int tendenciaCelebridade;
    private int tendenciaArtistica;

    public Resposta(String textoResposta, int sono, int comida, int social, int tendenciaMilionaria, int tendenciaFamiliar, int tendenciaCelebridade, int tendenciaArtistica) {
        this.textoResposta = textoResposta;
        this.sono = sono;
        this.comida = comida;
        this.social = social;
        this.tendenciaMilionaria = tendenciaMilionaria;
        this.tendenciaFamiliar = tendenciaFamiliar;
        this.tendenciaCelebridade = tendenciaCelebridade;
        this.tendenciaArtistica = tendenciaArtistica;
    }

    public String getTextoResposta() {
        return textoResposta;
    }

    public int getSono() {
        return sono;
    }

    public int getComida() {
        return comida;
    }

    public int getSocial() {
        return social;
    }

    public int getTendenciaMilionaria() {
        return tendenciaMilionaria;
    }

    public int getTendenciaFamiliar() {
        return tendenciaFamiliar;
    }

    public int getTendenciaCelebridade() {
        return tendenciaCelebridade;
    }

    public int getTendenciaArtistica() {
        return tendenciaArtistica;
    }
}
