package Pedro;

import java.util.*;

public class Jogador {
    private String nome;
    private ObjetivoVida objetivoDestino;
    private ObjetivoVida objetivoEscolhido;

    private int sonoMax = 100;
    private int sonoAtual;

    private int comidaMax = 100;
    private int comidaAtual;

    private int socialMax = 100;
    private int socialAtual;

    public Jogador() {

        Scanner input = new Scanner(System.in);

        System.out.println("Bem-vindo/a ao jogo");
        System.out.print("Como te chamas: ");
        String nomeEscolhido = input.nextLine();

        this.nome = nomeEscolhido;
        this.objetivoDestino = this.destinoEscolheObjetivo();
        this.mensagemDoFuturo();

        System.out.println("__________");

        this.questionarioInicial();


    }

    public ObjetivoVida destinoEscolheObjetivo() {

        ArrayList<ObjetivoVida> objetivosPossiveis = new ArrayList<>();
        objetivosPossiveis.add(ObjetivoVida.MILIONARIO);
        objetivosPossiveis.add(ObjetivoVida.FAMILIA);
        objetivosPossiveis.add(ObjetivoVida.CELEBRIDADE);
        objetivosPossiveis.add(ObjetivoVida.ARTISTA);

        Random rd = new Random();
        int indexObjetivoVidaDestino = rd.nextInt(objetivosPossiveis.size());
        ObjetivoVida objetivoVidaDestino = objetivosPossiveis.get(indexObjetivoVidaDestino);

        return objetivoVidaDestino;
    }

    public void mensagemDoFuturo() {

        Random rd = new Random();
        int indexMensagemEscolhida;

        String[] mensagensMilionario = new String[]{"Tio Patinhas", "Gostas de $$$", "Toca a amealhar","Cashing $$$"};
        String[] mensagensFamilia = new String[]{"Muita canalha pf", "Então? Quando há miudos?", "Casa cheia"};
        String[] mensagensCelebridade = new String[]{"CR7", "Mike Tyson", "Toda a gente te conhece"};
        String[] mensagensArtista = new String[]{"Picasso", "Quadros bonitos", "Desenhas bem"};

        switch (this.objetivoDestino) {
            case MILIONARIO:
                indexMensagemEscolhida = rd.nextInt(mensagensMilionario.length);
                System.out.println(mensagensMilionario[indexMensagemEscolhida]);
                break;

            case FAMILIA:
                indexMensagemEscolhida = rd.nextInt(mensagensFamilia.length);
                System.out.println(mensagensFamilia[indexMensagemEscolhida]);
                break;

            case CELEBRIDADE:
                indexMensagemEscolhida = rd.nextInt(mensagensCelebridade.length);
                System.out.println(mensagensCelebridade[indexMensagemEscolhida]);
                break;

            case ARTISTA:
                indexMensagemEscolhida = rd.nextInt(mensagensArtista.length);
                System.out.println(mensagensArtista[indexMensagemEscolhida]);
                break;

        }
    }

    public void questionarioInicial() {

        Scanner input = new Scanner(System.in);

        int contadorMilionario = 0, contadorFamilia = 0, contadorCelebridade = 0, contadorArtista = 0;

        // PERGUNTA 1
        Pergunta pergunta1 = new Pergunta("O que mais valorizas em ti?");
        pergunta1.adicionarRespostaPossivel(new Resposta("A minha disciplina e foco", 10, -5, 15, 1, 0, 1, 0));
        pergunta1.adicionarRespostaPossivel(new Resposta("A maneira como trato as pessoas", 5, 5, -20, 0, 1, 1, 0));
        pergunta1.adicionarRespostaPossivel(new Resposta("A minha originalidade", -15, 20, 0, 0, 0, 0, 1));

        // PERGUNTA 2
        Pergunta pergunta2 = new Pergunta("O que te irrita mais?");
        pergunta2.adicionarRespostaPossivel(new Resposta("Pessoas lentas ou preguiçosas", 15, -10, 15, 1, 0, 0, 0));
        pergunta2.adicionarRespostaPossivel(new Resposta("Falta de empatia", 5, 5, -20, 0, 1, 1, 0));
        pergunta2.adicionarRespostaPossivel(new Resposta("Falta de imaginação", -15, 20, 0, 0, 0, 0, 1));

        // PERGUNTA 3
        Pergunta pergunta3 = new Pergunta("Se ganhasses 1.000.000€ agora, o que farias?");
        pergunta3.adicionarRespostaPossivel(new Resposta("Investia", 15, -10, 15, 1, 0, 0, 0));
        pergunta3.adicionarRespostaPossivel(new Resposta("Ajudava familia/amigos", 5, 5, -20, 0, 1, 0, 0));
        pergunta3.adicionarRespostaPossivel(new Resposta("Criava algo novo", -15, 20, 0, 0, 0, 0, 1));
        pergunta3.adicionarRespostaPossivel(new Resposta("Gastava tudo numa VIPzaça", 20, -10, -15, 0, 0, 1, 0));

        // PERGUNTA 3
        Pergunta pergunta4 = new Pergunta("Se ganhasses 50€ agora, o que farias?");
        pergunta4.adicionarRespostaPossivel(new Resposta("Investia", 1, -1, 1, 1, 0, 0, 0));
        pergunta4.adicionarRespostaPossivel(new Resposta("Ajudava familia/amigos", 2, 2, -2, 0, 1, 0, 0));
        pergunta4.adicionarRespostaPossivel(new Resposta("Criava algo novo", -1, 2, 0, 0, 0, 0, 1));
        pergunta4.adicionarRespostaPossivel(new Resposta("Gastava tudo numa VIPzaça", 2, -1, -1, 0, 0, 1, 0));

        // QUESTIONÁRIO
        Questionario questionarioCriacaoPersonagem = new Questionario("Inicial");
        questionarioCriacaoPersonagem.adicionarPergunta(pergunta1);
        questionarioCriacaoPersonagem.adicionarPergunta(pergunta2);
        questionarioCriacaoPersonagem.adicionarPergunta(pergunta3);
        questionarioCriacaoPersonagem.adicionarPergunta(pergunta4);

        // COMEÇAR O QUESTIONÁRIO
        for (int i = 0; i < 2; i++) {
            Pergunta perguntaAtual = questionarioCriacaoPersonagem.getListaPerguntas().get(i);

            System.out.println(perguntaAtual.getTextoPergunta());
            perguntaAtual.apresentarRespostas();

            System.out.print("\nEscolhe: ");
            int escolhaJogador = input.nextInt();
            escolhaJogador--;

            Resposta respostaEscolhida = perguntaAtual.getRespostasPossiveis().get(escolhaJogador);
            this.sonoMax += respostaEscolhida.getSono();
            this.comidaMax += respostaEscolhida.getComida();
            this.socialMax += respostaEscolhida.getSocial();

            contadorMilionario += respostaEscolhida.getTendenciaMilionaria();
            contadorFamilia += respostaEscolhida.getTendenciaFamiliar();
            contadorCelebridade += respostaEscolhida.getTendenciaCelebridade();
            contadorArtista += respostaEscolhida.getTendenciaArtistica();
        }
        // ACABA QUESTIONÁRIO

        this.sonoAtual = this.sonoMax;
        this.comidaAtual = this.comidaMax;
        this.socialAtual = this.socialMax;


        if (contadorMilionario > contadorFamilia && contadorMilionario > contadorCelebridade && contadorMilionario > contadorArtista) {
            this.objetivoEscolhido = ObjetivoVida.MILIONARIO;
        } else if (contadorFamilia > contadorMilionario && contadorFamilia > contadorCelebridade && contadorFamilia > contadorArtista) {
            this.objetivoEscolhido = ObjetivoVida.FAMILIA;
        } else if (contadorCelebridade > contadorMilionario && contadorCelebridade > contadorFamilia && contadorCelebridade > contadorArtista) {
            this.objetivoEscolhido = ObjetivoVida.CELEBRIDADE;
        } else if (contadorArtista > contadorMilionario && contadorArtista > contadorFamilia && contadorArtista > contadorCelebridade) {
            this.objetivoEscolhido = ObjetivoVida.ARTISTA;
        } else {
            // Se empatar, começar com o do Destino
            this.objetivoEscolhido = this.objetivoDestino;
        }
    }

    public String getNome() {
        return nome;
    }

    public ObjetivoVida getObjetivoDestino() {
        return objetivoDestino;
    }

    public ObjetivoVida getObjetivoEscolhido() {
        return objetivoEscolhido;
    }

    public int getSonoMax() {
        return sonoMax;
    }

    public int getSonoAtual() {
        return sonoAtual;
    }

    public int getComidaMax() {
        return comidaMax;
    }

    public int getComidaAtual() {
        return comidaAtual;
    }

    public int getSocialMax() {
        return socialMax;
    }

    public int getSocialAtual() {
        return socialAtual;
    }

    public void exibirDetalhes() {
        System.out.println(this.nome);
        System.out.println("Objetivo Destinado: " + this.objetivoDestino);
        System.out.println("Objetivo Escolhido: " + this.objetivoEscolhido);
        System.out.println("Sono: " + this.sonoAtual + "/" + this.sonoMax);
        System.out.println("Comida: " + this.comidaAtual + "/" + this.comidaMax);
        System.out.println("Social: " + this.socialAtual + "/" + this.socialMax);
    }
}
